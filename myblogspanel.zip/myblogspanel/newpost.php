<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<style>
.formContainer {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
 
  
  }
  
  .formContent {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: #f1f1f1;
    padding: 20px;
    border-radius: 5px;
  }
  .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

</style>
<body>
<?php 
	$con = mysqli_connect("localhost","root","","blog");

	if(isset($_POST['submit'])){

$image = $_FILES['image']['name'];
$folder = "upload/".basename($image);
$name = $_POST['name'];
$description = $_POST['description'];






$query = "INSERT INTO `data`(`image`,`name`,`description`) VALUES ('$image','$name','$description')";

$run = mysqli_query($con , $query);
if(move_uploaded_file($_FILES['image']['tmp_name'],$folder)){

} 
else{
	echo "<script>
	alert();
	
	</script>";
}


 
	}

	
	?>







<div id="formContainer" class="formContainer">
  <form id="myForm" class="formContent" method="post" enctype="multipart/form-data" action="#">
  
	<h2>New Blog</h2>
	<label for="Image">Image:</label>
	<input type="file"  name="image" required><br><br>
	<label for="name">Your Name:</label>
	<input type="text"  name="name" required><br><br>
	<label for="Review">Description:</label>
	<input type="text"  name="description" required><br><br>
	<button type="submit" name="submit">Submit</button>
  </form>
</div>


	
	
</body>
</html>