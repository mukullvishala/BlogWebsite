<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	
</head>

<body>
    <style>
        .formContainer {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: none;
  
  }
  
  .formContent {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: #f1f1f1;
    padding: 20px;
    border-radius: 5px;
  }
  #openForm{
    background-color: black;color: white;border: 2px solid red; border-radius: 6px;width: 100px; height: 50px;font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif; margin-left: 47%;margin-top: 20%;
  }
    </style>
<?php 
	$con = mysqli_connect("localhost","root","","blog");

	if(isset($_POST['submit'])){

$image = $_FILES['image']['name'];
$folder = "upload/".basename($image);
$name = $_POST['name'];
$description = $_POST['description'];






$query = "INSERT INTO `data`(`image`,`name`,`description`) VALUES ('$image','$name','$description')";

$run = mysqli_query($con , $query);
if(move_uploaded_file($_FILES['image']['tmp_name'],$folder)){

} 
else{
	echo "<script>
	alert();
	
	</script>";
}


 
	}

	
	?>







<div id="formContainer" class="formContainer">
  <form id="myForm" class="formContent" method="post" enctype="multipart/form-data" action="#">
	<h2>Form Title</h2>
	<label for="Image">Image:</label>
	<input type="file"  name="image" required><br><br>
	<label for="name">Name:</label>
	<input type="text"  name="name" required><br><br>
	<label for="Review">Review Here:</label>
	<input type="text"  name="description" required><br><br>
	<button type="submit" name="submit">Submit</button>
  </form>
</div>


	
	
<!-- Code injected by live-server -->
<script>
	// <![CDATA[  <-- For SVG support
	if ('WebSocket' in window) {
		(function () {
			function refreshCSS() {
				var sheets = [].slice.call(document.getElementsByTagName("link"));
				var head = document.getElementsByTagName("head")[0];
				for (var i = 0; i < sheets.length; ++i) {
					var elem = sheets[i];
					var parent = elem.parentElement || head;
					parent.removeChild(elem);
					var rel = elem.rel;
					if (elem.href && typeof rel != "string" || rel.length == 0 || rel.toLowerCase() == "stylesheet") {
						var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
						elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + (new Date().valueOf());
					}
					parent.appendChild(elem);
				}
			}
			var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
			var address = protocol + window.location.host + window.location.pathname + '/ws';
			var socket = new WebSocket(address);
			socket.onmessage = function (msg) {
				if (msg.data == 'reload') window.location.reload();
				else if (msg.data == 'refreshcss') refreshCSS();
			};
			if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
				console.log('Live reload enabled.');
				sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
			}
		})();
	}
	else {
		console.error('Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
	}
	// ]]>
</script>
</body>
</html>