<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <style>
    *{
    margin: 0;
    padding: 0;
    font-family: "montserrat",sans-serif;
  }
  .testimonials{
    padding: 40px 0;
 

    text-align: center;
  }
  .inner{
    max-width: 1200px;
    margin: auto;
    overflow: hidden;
    padding: 0 20px;
  }
  
   
  .border{
    width: 160px;
    height: 5px;
    background: #6ab04c;
    margin: 26px auto;
  }
   
  .row{
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
  }
  .col{
    flex: 33.33%;
    max-width: 33.33%;
    box-sizing: border-box;
    padding: 15px;
  }
  .testimonial{
    background: #fff;
    padding: 30px;
  }
  .testimonial img{
    width: 100px;
    height: 100px;
    border-radius: 50%;
  }
  .name{
    font-size: 20px;
    text-transform: uppercase;
    margin: 20px 0;
  }
  .stars{
    color: #6ab04c;
    margin-bottom: 20px;
  }
  .top{
    padding: 40px 0;
    background: #f1f1f1;
  
    text-align: center;
  }
   
  @media screen and (max-width:960px) {
  .col{
    flex: 100%;
    max-width: 80%;
  }
  }
   
  @media screen and (max-width:600px) {
  .col{
    flex: 100%;
    max-width: 100%;
  }
  }
  
  </style>
   <div class="top">
 <h1>OUR BLOGS</h1>
      <div class="border"></div>
 </div>
  <?php


$con = mysqli_connect("localhost","root","","blog");
$query2 = "SELECT * FROM `data` WHERE 1";
$run2  = mysqli_query($con , $query2);





?>

<?php
while($row = mysqli_fetch_assoc($run2)){
	?>

  <div class="testimonials">
   
          <div class="testimonial">
          <img src="upload/<?php echo $row ['image']?>"/>
            <div class="name"><?php echo $row ['name'] ?></div>
        

            <p>
                <?php echo $row['description'] ?>
                <?php
}

?>
            </p>
          </div>
        </div>


</body>
</html>